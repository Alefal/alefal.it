<?php
require_once('../../../wp-config.php');

global $wpdb;

$teamsArray = array();
$resultArray = array();
$finalArray = array();
 
$teams = $wpdb->get_results("select id,post_title from wp_posts where post_type = 'tb_club' and post_status = 'publish' order by post_title");

$resultArray[] = array(
    'result'  => 'OK',
    'message' => 'OK'
);

//print_r($teams);
foreach ($teams as $team) {
    $teamsArray[] = array(        
        'SquadraId'     => $team->id,
        'Squadra'       => $team->post_title
    );  
}

$finalArray[] = array(
    'response'   => $resultArray,
    'teams'   => $teamsArray
);
echo json_encode($finalArray);
exit();