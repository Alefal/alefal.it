=== Material Admin Theme ===
Contributors: chmln
Tags: theme, basic, clean, minimalistic, wordpress admin, backend, backend theme, admin theme, custom admin, custom admin theme, flat, material,
Requires at least: 3.0
Tested up to: 4.5
Stable tag: 1.3.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Material blue theme for wordpress admin. Flat design, improved contrast. Have your backend look like 2015.

== Description ==

The look of wordpress backend is dated. This eye-pleasing theme delivers better contrast and a modern look.

== Installation ==

Just hit 'Install Now'

== Frequently Asked Questions ==

== Screenshots ==

1. Dashboard View
2. Contrast: even rows are distinguishably gray
3. Smooth typography and some transparency for an eye-candy look

== Changelog ==

= 1.3 =
* Fix input bugs in Appearance->Menus
* Revert back to Open Sans for faster page loads
* Reduce visual traction in submenus with slight background hover effect

= 1.2 =
* Improved accessibility
* Added a bit of transparency to submenus
* Bugfixes

= 1.1 =
* Color scheme changes - screaming red to flat ocean blue
* Improved contrast between rows in posts, pages, etc
* Improved typography
* Flat buttons
* Numerous bugfixes

= 1.0 =
* initial version

== Upgrade Notice ==


Admin colour, Admin theme style plugin, back end theme, backend, background colour, background theme style plugin, Best admin theme, Best Admin theme style plugin, Best back-end, Best backend theme style plugin, colour, Custom admin theme, customized admin theme, Customized WordPress admin theme, Download Admin theme style plugin, Download backend theme style plugin, Free admin theme style plugin, Free backend theme style plugin, navigation menu, new admin ui
