# angular-translate (bower shadow repository)

This is the _Bower shadow_ repository for *angular-translate*.

## Bugs and issues

Please file any issues and bugs in our main repository at [angular-translate/angular-translate](https://github.com/angular-translate/angular-translate/issues).

## Usage

### via Bower

```bash
$ bower install angular-translate
```

### via cdnjs

Please have a look at https://cdnjs.com/libraries/angular-translate for specific versions.

## License

Licensed under MIT. See more details at [angular-translate/angular-translate](https://github.com/angular-translate/angular-translate).
