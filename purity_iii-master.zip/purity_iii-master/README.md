Hello world, this is Purity III
==========

About me:
---------------------------
Purity III is a Responsive Joomla template for Joomla 3. A great starter theme for any Joomla lovers. A perfect starting point in any Joomla project. 

Why I’m - Purity III is the best?
---------------------------

- Fully Responsive
- Extreme user-friendly (ThemeMagic)
- 13+ ready-to-use layouts
- Highly compatible with 3rd party extensions
- Built on the latest T3 Framework version (check out its release announcement here)
- Native RTL layout support (WIP)
- Stunning typography pages including pricing tables, team pages, etc.
- Extended com_content features such as extra fields.
- and lastly.... It's FREE

How to Download Purity III?
---------------------------

You can get a hand on Purity III here at @ https://github.com/t3framework/purity_iii

As Purity III is built on the T3 framework, it’s required to install and enable T3 Framework before hand. Get your T3 Framework @ https://github.com/t3framework/t3/tags

Or get the full package of both here @ http://www.joomlart.com/forums/downloads.php?do=cat&id=519

See Purity III in action 
---------------------------

- Live demo: http://www.joomlart.com/demo/#purity_iii

Looking for Help & Documentation?
---------------------------

- Official documentation: http://www.joomlart.com/documentation/joomla-templates/purity-iii
- Seek help & support at Purity III public discussion forum: http://www.joomlart.com/forums/forumdisplay.php?542-Purity-III

Contribution
---------------------------

We LOVE sharing, and Purity III is not an exception. If you want to contribute in term of code by submitting your request on a 3rd party extensions compatibility here at Github or a translation of Purity III, please feel welcome. Details on how to do the above can be found at: http://www.joomlart.com/forums/showthread.php?95819-Purity-III-Third-party-extension&p=411915. 

Credits, Copyrights and License
---------------------------

Copyright © 2014 T3 Canvas. All Rights Reserved. Designed by JoomlArt.com.
Joomla! is Free Software released under the GNU General Public License.
Bootstrap is a front-end framework of Twitter, Inc. Code licensed under Apache License v2.0.
Font Awesome font licensed under SIL OFL 1.1.



